from django.apps import AppConfig


class ReservationsConfig(AppConfig):
    name = 'reservations'
